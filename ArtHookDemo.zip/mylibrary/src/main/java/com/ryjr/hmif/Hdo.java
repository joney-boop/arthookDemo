package com.ryjr.hmif;

import android.content.ComponentName;
import android.content.pm.ApplicationInfo;
import android.util.Log;


import com.ryjr.hmif.utils.ObjectUtils;

import java.lang.reflect.Field;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.util.Arrays;


public class Hdo {

    static {
        System.loadLibrary("fh");
    }


    public static void customHook(ClassLoader classLoader) {
        try {
            batchHook(classLoader, Test.class);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void batchHook(ClassLoader classLoader,Class hookClass) {

        try {
            Field field = ObjectUtils.findField(hookClass, "HOOK_ITEMS");
            String[][] hookItems = (String[][]) field.get(null);

            if (hookItems == null) {
                Log.e("Hdo", "hook items is null");
                return;
            }
            for (int i = 0; i < hookItems.length; i++) {
                String[] hookItem = hookItems[i];
                if (hookItem.length != DefaultConfig.HOOK_ITEM_SIZE) {
                    Log.e("Hdo", "invalid hook item size:" + hookItem.length + " item:" + Arrays.toString(hookItem));
                    continue;
                }
                Member targetMethod = ObjectUtils.getMethod(hookItem[1], hookItem[2], hookItem[3], classLoader, null, null);
                Member hookMethod = ObjectUtils.getMethod(hookItem[4], hookItem[5], hookItem[6], null, null, null);
                Member forwardMethod = ObjectUtils.getMethod(hookItem[7], hookItem[8], hookItem[9], null, null, null);
                if (targetMethod == null || hookMethod == null) {
                    Log.e("Hdo", "invalid target method or hook method item:" + Arrays.toString(hookItem));
                    continue;
                }

                hook(targetMethod, hookMethod, forwardMethod, Integer.parseInt(hookItem[0]) == 1 ? true : false);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public native static void hook(Member targetMethod, Member hookMethod, Member forwardMethod, boolean isStatic);


}
