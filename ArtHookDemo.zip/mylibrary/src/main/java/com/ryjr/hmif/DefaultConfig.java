package com.ryjr.hmif;


public  class DefaultConfig {
    public static String ISTATIC = "1";
    public static String NOTSTATIC = "0";
    public final static int HOOK_ITEM_SIZE = 10;








}
