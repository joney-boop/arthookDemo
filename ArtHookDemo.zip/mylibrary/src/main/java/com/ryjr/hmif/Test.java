package com.ryjr.hmif;

public class Test {

    private static String ISTATIC = "1";
    private static String NOTSTATIC = "0";
    private static String HOOK_CLASS = "com.ryjr.hmif.Test";

    private static String[] mHookItemtest = {
            ISTATIC,
            "com.ryjr.hmif.Test", "addTest", "",
            HOOK_CLASS, "hookAddTest", "",
            HOOK_CLASS, "forwardAddTest", ""
    };
    private static String[][] HOOK_ITEMS = {
            mHookItemtest};
    public static int addTest() {
        return 1 + 1;
    }

    public static int hookAddTest() {
        return 2 + 2;
    }

    public static native int forwardAddTest();
}